sap.ui.define([
	"sap/ui/test/Opa5",
	"ztsg/northwind/test/integration/arrangements/Arrangement",
	"ztsg/northwind/test/integration/NavigationJourneyPhone",
	"ztsg/northwind/test/integration/NotFoundJourneyPhone",
	"ztsg/northwind/test/integration/BusyJourneyPhone"
], function (Opa5, Arrangement) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "ztsg.northwind.view.",
		autoWait: true
	});
});
